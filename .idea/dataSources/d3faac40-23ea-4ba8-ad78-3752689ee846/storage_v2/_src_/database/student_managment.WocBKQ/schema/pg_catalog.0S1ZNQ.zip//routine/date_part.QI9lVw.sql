create function date_part(text, date) returns double precision
    immutable
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

comment on function date_part(text, date) is 'extract field from date';

alter function date_part(text, date) owner to postgres;

